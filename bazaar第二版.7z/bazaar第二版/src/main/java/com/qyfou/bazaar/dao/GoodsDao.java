package com.qyfou.bazaar.dao;

import com.qyfou.bazaar.model.Goods;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;


public interface GoodsDao {
      List<Goods> selectGoodsByUserId(@Param("userId") Long userId, @Param("type") Integer type, @Param("current") int current, @Param("count") int count);

      List<Goods> selectCollectionByUserId(@Param("userId") Long userId,@Param("type") Integer type,@Param("current") int current,@Param("count") int count);

      Integer getGoodsNum(@Param("userId")Long userId, @Param("type") Integer type);

      Integer getCollectionNum(@Param("userId")Long userId, @Param("type") Integer type);




      List<Goods> selectRandom(@Param("type") Integer type,@Param("count") int count);





      List<Goods> selectByPriceDesc(@Param("type") Integer type,@Param("current") int current,@Param("count") int count);

      List<Goods> selectByPriceAsc(@Param("type") Integer type,@Param("current") int current,@Param("count") int count);

      List<Goods> selectByHeat(@Param("type") Integer type,@Param("current") int current,@Param("count") int count);

      List<Goods> selectByTime(@Param("type") Integer type,@Param("current") int current,@Param("count") int count);

      List<Goods> selectByClass(@Param("type") Integer type,@Param("words") List<String> words,
                                 @Param("current") int current,@Param("count") int count);

      int getClassNum(@Param("type") Integer type,@Param("words") List<String> words);

      List<Goods> selectByDiscover(@Param("type") Integer type,@Param("words") List<String> words,
                                @Param("current") int current,@Param("count") int count);

      int getDiscoverNum(@Param("type") Integer type,@Param("words") List<String> words);
}
