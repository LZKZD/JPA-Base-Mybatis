package com.qyfou.bazaar.service;

public interface UserService {
    Long selectIdByOpenId(String openId);
}
