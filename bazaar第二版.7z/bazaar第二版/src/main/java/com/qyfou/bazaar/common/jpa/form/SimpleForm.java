package com.qyfou.bazaar.common.jpa.form;

/**
 * id表单
 *
 * @author jjh
 * @date 2019/6/1
 **/
public class SimpleForm {

    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
