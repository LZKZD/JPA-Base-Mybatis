package com.qyfou.bazaar.service;

import com.qyfou.bazaar.model.Goods;

import java.util.List;

public interface ClassService {
    List<Goods> getGoodsByClass(Integer type, List<String> words, int current, int count);

    Integer getClassNum(Integer type,List<String> words);

   List<Goods> getGoodsByDiscover(Integer type, List<String> words, int current, int count);

    Integer getDiscoverNum(Integer type,List<String> words);
}
