package com.qyfou.bazaar.service;

public interface AddressService {
    Object updateAddress(Long id,String tname,String location,String phone);
}
