package com.qyfou.bazaar.controller;

import com.qyfou.bazaar.service.ClassService;
import com.qyfou.bazaar.service.impl.ClassServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/class")
public class ClassController {
        @Autowired
    private ClassServiceImpl classServiceImpl;

    //根据类别获取对应符合条件的商品、拍卖品
    @GetMapping("/category")
    public Object getGoodsByClass(Integer type, List<String> words,int pageNum,int pageSize){
        return classServiceImpl.getGoodsByClass(type,words, pageNum*pageSize, pageSize);
    }

    //根据类别获取对应符合条件的商品、拍卖品数量
    @GetMapping("/category/nums")
    public Object getClassPages(Integer type,List<String> words){
        return classServiceImpl.getClassNum(type,words);
    }

    //根据搜索条件获取对应符合条件的商品、拍卖品
    @GetMapping("/discover")
    public Object getGoodsByDiscover(Integer type, List<String> words, int pageNum,int pageSize){
        return classServiceImpl.getGoodsByDiscover(type,words, pageNum*pageSize, pageSize);
    }

    //根据搜索条件获取对应符合条件的商品、拍卖品数量
    @GetMapping("/discover/nums")
    public Object getDiscoverPages(Integer type,List<String> words){
        return classServiceImpl.getDiscoverNum(type,words);
    }
}
