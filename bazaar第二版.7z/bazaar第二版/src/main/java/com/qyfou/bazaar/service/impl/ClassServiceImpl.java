package com.qyfou.bazaar.service.impl;

import com.qyfou.bazaar.dao.GoodsDao;
import com.qyfou.bazaar.model.Goods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClassServiceImpl {
     @Autowired
    private GoodsDao goodsDao;

     public List<Goods> getGoodsByClass(Integer type, List<String> words, int current, int count) {
        return goodsDao.selectByClass(type,words,current,count);
    }

    public Integer getClassNum(Integer type,List<String> words) {
        return goodsDao.getClassNum(type,words);
    }

    public List<Goods> getGoodsByDiscover(Integer type, List<String> words, int current, int count) {
        return goodsDao.selectByDiscover(type,words,current,count);
    }

    public Integer getDiscoverNum(Integer type,List<String> words) {
        return goodsDao.getDiscoverNum(type,words);
    }
}
